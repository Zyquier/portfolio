package com.example.demo.student;
//  data that is being added to my database

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.util.List;

@Configuration
public class StudentConfig {
    @Bean
    CommandLineRunner commandLineRunner(StudentRespiratory respiratory) {
        return args -> {
            Student zyquier = new Student(

                    "Zyquier",
                    "zy.z@gmail.com",
                    LocalDate.of( 1999, 2, 9 ) );
            Student marco = new Student(
                    "Marco",
                    "mc.m@gmail.com",
                    LocalDate.of( 1980, 3, 5 ) );
            respiratory.saveAll(
                    List.of( zyquier, marco )
            );


        };
    }


}
